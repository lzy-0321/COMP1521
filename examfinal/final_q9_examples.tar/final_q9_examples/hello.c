#include <stdio.h>

int main(void) {
    puts("Hello, world!");
    return 0;
}
