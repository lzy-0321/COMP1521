#! /usr/bin/env perl

print "Hello, world!\n";
